package com.cg.bam.exception;

public class BankAccountException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3035276355853496121L;

	public BankAccountException(String message){
		super(message);
	}
}
