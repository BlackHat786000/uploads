package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HotelBookingPageFactory {

	
		
		WebDriver driver;
	//First Name	
		@FindBy(name="txtFN")
		@CacheLookup
		WebElement pffname;
		
	//Last Name	
		@FindBy(name="txtLN")
		@CacheLookup
		WebElement pflname;
		
	//Email	
		@FindBy(name="Email")
		@CacheLookup
		WebElement pfemail;
		
	//Mobile No.
		@FindBy(name="Phone")
		@CacheLookup
		WebElement pfphone;   
		
	//Address	
		@FindBy(xpath="html/body/div[1]/div/form/table/tbody/tr[6]/td[2]/textarea")
		@CacheLookup
		WebElement address;
		
	//City	
		@FindBy(xpath="html/body/div[1]/div/form/table/tbody/tr[7]/td[2]/select")
		@CacheLookup
		WebElement city;
		
	//State
		@FindBy(xpath="html/body/div/div/form/table/tbody/tr[8]/td[2]/select")
		@CacheLookup
		WebElement state;
		
	//Guests	
		@FindBy(xpath="html/body/div[1]/div/form/table/tbody/tr[10]/td[2]/select")
		@CacheLookup
		WebElement guest;
	//Rooms	
		@FindBy(id="rooms")
		@CacheLookup
		WebElement room;
		
	//Rooms Booked	
		@FindBy(xpath=".//*[@id='rooms']")
		@CacheLookup
		WebElement roombooked;
		
	//Card Holder Name	
		@FindBy(id="txtCardholderName")
		@CacheLookup
		WebElement cname;
	
	//Debit card Number	
		@FindBy(id="txtDebit")
		@CacheLookup
		WebElement debit;
		
	//CVV	
		@FindBy(id="txtCvv")
		@CacheLookup
		WebElement cvv;
		
	//Expiration Month	
		@FindBy(id="txtMonth")
		@CacheLookup
		WebElement expmonth;
		
	//Expiration Year	
		@FindBy(id="txtYear")
		@CacheLookup
		WebElement expyear;
		
		@FindBy(id="btnPayment")
		@CacheLookup
		WebElement button;
		
		


public HotelBookingPageFactory(WebDriver driver) {
			
			this.driver = driver;
			PageFactory.initElements(driver, this);
			
		}


public WebElement getPffname() {
	return pffname;
}


public void setPffname(String fname) {
	pffname.sendKeys(fname);
}


public WebElement getPflname() {
	return pflname;
}


public void setPflname(String lname) {
	pflname.sendKeys(lname);
}


public WebElement getPfemail() {
	return pfemail;
}


public void setPfemail(String email) {
	pfemail.sendKeys(email);
}

public WebElement getPfphone() {
	return pfphone;
}


public void setPfphone(String phone) {
	pfphone.sendKeys(phone);
}

public WebElement getAddress() {
	return address;
}


public void setAddress(String add) {
	address.sendKeys(add);
}


public WebElement getCity() {
	return city;
}


public void setCity(String citystr) {
	city.sendKeys(citystr);
}

public WebElement getGuest() {
	return guest;
}




public WebElement getState() {
	return state;
}


public void setState(String states) {
	state.sendKeys(states);
}


public void setGuest(String guests) {
	guest.sendKeys(guests);
}


public WebElement getRoombooked() {
	return roombooked;
}


public void setRoombooked(String room) {
	roombooked.sendKeys(room);
}


public WebElement getCname() {
	return cname;
}


public void setCname(String name) {
	cname.sendKeys(name);
}


public WebElement getDebit() {
	return debit;
}


public void setDebit(String strdebit) {
     debit.sendKeys(strdebit);
}


public WebElement getCvv() {
	return cvv;
}


public void setCvv(String strcvv) {
	cvv.sendKeys(strcvv);
}


public WebElement getExpmonth() {
	return expmonth;
}


public void setExpmonth(String month) {
	expmonth.sendKeys(month);
}


public WebElement getExpyear() {
	return expyear;
}


public void setExpyear(String year) {
	expyear.sendKeys(year);
}
		
public WebElement getButton() {
	return button;
}


public void setButton() {
	button.click();
}
	
		
		
}
