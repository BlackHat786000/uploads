package HotelBooking;

import static org.testng.Assert.assertEquals;
import java.util.List;
import java.util.regex.Pattern;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.HotelBookingPageFactory;

public class StepDefinitionHotelBooking {

	private WebDriver driver;
	private HotelBookingPageFactory obj1;

	public void salert() {
		Alert alert = driver.switchTo().alert();
		String msg = alert.getText();
		System.out.println(msg);
		driver.switchTo().alert().accept();
		driver.quit();
	}

	@Given("^User is on booking page$")
	public void user_is_on_booking_page() throws Throwable {
		driver = new FirefoxDriver();

		obj1 = new HotelBookingPageFactory(driver);

		driver.get("file:///D:/Module%203/hotelBooking/hotelbooking.html");
	}

	@Then("^check the title of page$")
	public void check_the_title_of_page() throws Throwable {

		String title = driver.getTitle();

		if (title.contentEquals("Hotel Booking")) {

			System.out.println("====VALID TITLE====");
		}

		else {

			System.out.println("====INVALID TITLE====");
		}
		driver.quit();
	}

	@When("^User does not enter firstname , lastname$")
	public void user_does_not_enter_firstname_lastname() throws Throwable {

		driver.manage().window().maximize();
		obj1.setPffname("");
		obj1.setButton();

	}

	@Then("^prompt user to fill in details$")
	public void prompt_user_to_fill_in_details() throws Throwable {

		Alert alert = driver.switchTo().alert();
		String msg = alert.getText();
		System.out.println(msg);
		driver.switchTo().alert().accept();
		driver.quit();
	}

	@When("^User does not enter email in correct format$")
	public void user_does_not_enter_email_in_correct_format() throws Throwable {

		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("any invalid input");
		obj1.setButton();
	}

	@Then("^prompt user to write input correctly$")
	public void prompt_user_to_write_input_correctly() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String msg = alert.getText();
		System.out.println(msg);
		driver.switchTo().alert().accept();
		driver.quit();
	}

	@When("^User does not enter mobile number$")
	public void user_does_not_enter_mobile_number() throws Throwable {

		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		obj1.setPfphone("");
		obj1.setButton();
	}

	@Then("^prompt user to enter mobile number$")
	public void prompt_user_to_enter_mobile_number() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String msg = alert.getText();
		System.out.println(msg);
		driver.switchTo().alert().accept();
		driver.quit();
	}

	@When("^User enters invalid mobile no\\.$")
	public void user_enters_invalid_mobile_no(DataTable arg1) throws Throwable {

		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		List<String> objList = arg1.asList(String.class);

		for (int i = 0; i < objList.size(); i++) {
			obj1.getPfphone().clear();
			obj1.setPfphone(objList.get(i));
			Thread.sleep(1000);
			obj1.setButton();
			Alert alert = driver.switchTo().alert();
			String msg = alert.getText();
			System.out.println(msg);
			driver.switchTo().alert().accept();
			if (Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) {
				System.out.println("***** Matched" + objList.get(i) + "*****");
			} else {
				System.out.println("***** NOT Matched" + objList.get(i) + "*****");
				
			}
		}obj1.setButton();
		
	}

	@Then("^prompt user to enter valid contact details$")
	public void prompt_user_to_enter_valid_contact_details() throws Throwable {

		Alert alert = driver.switchTo().alert();
		String msg = alert.getText();
		System.out.println(msg);
		driver.switchTo().alert().accept();
		driver.quit();
	}
	

	@When("^user enters (\\d+)$")
	public void user_enters(int arg1) throws Throwable {
		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		obj1.setPfphone("8130497696");
		obj1.setAddress("MB-40, Dilshad Garden, New Delhi");
		obj1.setCity("Pune");
		obj1.setState("Maharashtra");
		obj1.setGuest(""+arg1);
//		Thread.sleep(10000);
	   
	}

	@Then("^for (\\d+) number of guests, allocate (\\d+) number of rooms$")
	public void for_number_of_guests_allocate_number_of_rooms(int arg1, int arg2) throws Throwable {
		System.out.println("Rooms : "+arg2);
	   if(arg1<=3) {
		   String number = obj1.getRoombooked().getText();
		   int intnum = Integer.parseInt(number);
		   System.out.println("++++++++++"+number+"+++++++++");
		   assertEquals(intnum,arg2);
		   driver.quit();
	   }
	   else if(arg1<=6) {
		   System.out.println("Waiting............................");
		   Thread.sleep(10000);
		   System.out.println("Waiting............................");
		   Thread.sleep(10000);                                                 
		   String number1 = obj1.getRoombooked().getText();
		   int intnum1 = Integer.parseInt(number1);
		   System.out.println("++++++++++"+number1+"+++++++++");
		   assertEquals(intnum1,arg2);
		   driver.quit();
	   }
	   else if(arg1<=9) {
		   System.out.println("Waiting............................");
		   Thread.sleep(10000);
		   System.out.println("Waiting............................");
		   Thread.sleep(10000);                                                         
		   String number2 = obj1.getRoombooked().getText();
		   int intnum2 = Integer.parseInt(number2);
		   System.out.println("++++++++++"+number2+"+++++++++");
		   assertEquals(intnum2,arg2);
		   driver.quit();
	   }
	   
	}


	@When("^User does not address$")
	public void user_does_not_address() throws Throwable {
		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		obj1.setPfphone("8130497696");
		obj1.setAddress("");
		obj1.setButton();

	}

	@Then("^prompt user to fill in the address$")
	public void prompt_user_to_fill_in_the_address() throws Throwable {
		Alert alert = driver.switchTo().alert();
		String msg = alert.getText();
		System.out.println(msg);
		driver.switchTo().alert().accept();
		driver.quit();
	}

	@When("^User does not select city$")
	public void user_does_not_select_city() throws Throwable {
		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		obj1.setPfphone("8130497696");
		obj1.setAddress("MB-40, Dilshad Garden, New Delhi");
		obj1.setCity("");
		obj1.setButton();

	}

	@Then("^prompt user to select city$")
	public void prompt_user_to_select_city() throws Throwable {
		salert();
	}

	@When("^User does not select state$")
	public void user_does_not_select_state() throws Throwable {
		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		obj1.setPfphone("8130497696");
		obj1.setAddress("MB-40, Dilshad Garden, New Delhi");
		obj1.setCity("Pune");
		obj1.setState("");
		obj1.setButton();

	}

	@Then("^prompt user to select state$")
	public void prompt_user_to_select_state() throws Throwable {
		salert();
	}

	@When("^User does not enter card holder name$")
	public void user_does_not_enter_card_holder_name() throws Throwable {
		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		obj1.setPfphone("8130497696");
		obj1.setAddress("MB-40, Dilshad Garden, New Delhi");
		obj1.setCity("Pune");
		obj1.setState("Maharashtra");
		obj1.setCname("");
		obj1.setButton();
	}

	@Then("^prompt user to fill in card holder name$")
	public void prompt_user_to_fill_in_card_holder_name() throws Throwable {
		salert();
	}

	@When("^User does not enter debit card number$")
	public void user_does_not_enter_debit_card_number() throws Throwable {
		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		obj1.setPfphone("8130497696");
		obj1.setAddress("MB-40, Dilshad Garden, New Delhi");
		obj1.setCity("Pune");
		obj1.setState("Maharashtra");
		obj1.setCname("Udit Yadav");
		obj1.setDebit("");
		obj1.setButton();

	}

	@Then("^prompt user to enter debit card number$")
	public void prompt_user_to_enter_debit_card_number() throws Throwable {
		salert();
	}

	@When("^User does not enter card expiration month$")
	public void user_does_not_enter_card_expiration_month() throws Throwable {
		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		obj1.setPfphone("8130497696");
		obj1.setAddress("MB-40, Dilshad Garden, New Delhi");
		obj1.setCity("Pune");
		obj1.setState("Maharashtra");
		obj1.setCname("Udit Yadav");
		obj1.setDebit("4371878992134651");
		obj1.setExpmonth("");
		obj1.setButton();
	}

	@Then("^prompt user to enter card expiration month$")
	public void prompt_user_to_enter_card_expiration_month() throws Throwable {
		salert();
	}

	@When("^User does not enter card expiration year$")
	public void user_does_not_enter_card_expiration_year() throws Throwable {
		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		obj1.setPfphone("8130497696");
		obj1.setAddress("MB-40, Dilshad Garden, New Delhi");
		obj1.setCity("Pune");
		obj1.setState("Maharashtra");
		obj1.setCname("Udit Yadav");
		obj1.setDebit("4371878992134651");
		obj1.setExpmonth("10");
		obj1.setExpyear("");
		obj1.setButton();
	}

	@Then("^prompt user to enter card expiration year$")
	public void prompt_user_to_enter_card_expiration_year() throws Throwable {
		salert();
	}

	@When("^User clicks on confirm booking button$")
	public void user_clicks_on_confirm_booking_button() throws Throwable {
		driver.manage().window().maximize();
		obj1.setPffname("Udit");
		obj1.setPflname("Yadav");
		obj1.setPfemail("yadavudit786@gmail.com");
		obj1.setPfphone("8130497696");
		obj1.setAddress("MB-40, Dilshad Garden, New Delhi");
		obj1.setCity("Pune");
		obj1.setState("Maharashtra");
		obj1.setCname("Udit Yadav");
		obj1.setDebit("4371878992134651");
		obj1.setCvv("420");
		obj1.setExpmonth("10");
		obj1.setExpyear("2016");
		obj1.setButton();
	}

	@Then("^navigate to booking successful$")
	public void navigate_to_booking_successful() throws Throwable {
		driver.navigate().to("file:///D:/Module%203/hotelBooking/success.html");
		Thread.sleep(1000);
		driver.quit();
	}

}
