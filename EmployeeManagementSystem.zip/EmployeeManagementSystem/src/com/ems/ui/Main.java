package com.ems.ui;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import com.ems.dto.Employee;
import com.ems.exception.EmployeeException;
import com.ems.service.EmployeeService;
import com.ems.service.EmployeeServiceImpl;

public class Main {
	
	public static void main(String args[]) throws EmployeeException{
		
		EmployeeService service = new EmployeeServiceImpl();
		Scanner sc = new Scanner(System.in);
		try {
		int ch=0;
		
		
		String name,mobileno,project;
		double salary;
		int id;
		
		while(ch!=5) {
			
			System.out.println("1. Add Employee\n2. Display Employee\n3. Display Employee based on Project\n4. Update Employee Details\n5. Exit");
			
			ch = sc.nextInt();
			
			switch(ch) {
			
			case 1:
				Employee employee = new Employee();
				do {
					
					System.out.println("Enter name of employee : ");
					name = sc.next();
					
					System.out.println("Enter mobile number of employee : ");
					mobileno = sc.next();
					
					System.out.println("Enter project of employee : ");
					project = sc.next();
					
					System.out.println("Enter salary of employee : ");
					salary = sc.nextDouble();
					
					employee.setEname(name);
					employee.setMobileno(mobileno);
					employee.setProject(project);
					employee.setSalary(salary);
					
					if(service.validateEmployee(employee)==null)
						System.out.println("Invalid Details");
					else break;
				}while(true); 
				
				service.createEmployee(employee);
				break;
				
			case 2 : System.out.println("Enter employee ID to view details : ");
			id = sc.nextInt();
			Employee emp = new Employee();
			emp = service.displayEmployee(id);
			System.out.println("Name : "+emp.getEname()+"\nMobile Number : "+emp.getMobileno()+"\nProject : "+emp.getProject()+"\nSalary : "+emp.getSalary());
			
			try {
				if(System.in.read()=='\n') {
				break;}
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		break;
			
			case 3 : System.out.println("Enter the project name : ");
			project = sc.next();
			ArrayList<Employee> displayEmployee = service.displayProjectEmployee(project);
			
			System.out.println("Employee ID        Name        Mobile No.                 Project               Salary");
			
			for (Employee e : displayEmployee) {
				System.out.print(e.getEid()+"                ");
				System.out.print(e.getEname()+"        ");
				System.out.print(e.getMobileno()+"                 ");
				System.out.print(e.getProject()+"                  ");
				System.out.println(e.getSalary());
				}
			
			try {
				if(System.in.read()=='\n') {
				break;}
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		break;
			
			case 4 : Employee empUpdate = new Employee();
			
			do{
				System.out.println("Enter the Employee ID : ");
				id = sc.nextInt();
				
				System.out.println("Enter Mobile Number : ");
				mobileno = sc.next();
				
				System.out.println("Enter Project : ");
				project = sc.next();
				
				empUpdate.setMobileno(mobileno);
				empUpdate.setProject(project);
				
				if(service.validateMobileNo(empUpdate.getMobileno()))
					break;
			
			}while(true);		
			service.updateEmployeeDetails(id, empUpdate);
		
		break;
		
			case 5 :
				System.out.println("Exiting......EMS Application is now closed");
			break;
		default : System.out.println("Invalid Input!!!!");
		
		}
			
	}
		} finally {
			sc.close();
		}
}
	
}
			
		
					
					
					
					
					
					
					
					
					
					
					
					
					
			
			
			
			
			
			
			
		
		
		
		
		
		
		
		
		
		
		
		
		
