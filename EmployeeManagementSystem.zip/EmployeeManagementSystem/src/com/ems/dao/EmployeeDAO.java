package com.ems.dao;

import java.util.ArrayList;

import com.ems.dto.Employee;
import com.ems.exception.EmployeeException;

public interface EmployeeDAO {
	
	public void createEmployee(Employee employee) throws EmployeeException;
	
	public Employee displayEmployee(int eid)throws EmployeeException;
	
	public void updateEmployeeDetails(int eid, Employee employee)throws EmployeeException;
	
	public ArrayList<Employee> displayProjectEmployee(String project)throws EmployeeException;	

}
