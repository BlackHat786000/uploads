package HotelBooking;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinitionHotelBooking {

	@Given("^User is on booking page$")
	public void user_is_on_booking_page() throws Throwable {

	}

	@When("^User does not enter firstname , lastname$")
	public void user_does_not_enter_firstname_lastname() throws Throwable {

	}

	@Then("^prompt user to fill in details$")
	public void prompt_user_to_fill_in_details() throws Throwable {

	}

	@When("^User does not enter email in correct format$")
	public void user_does_not_enter_email_in_correct_format() throws Throwable {

	}

	@Then("^prompt user to write input correctly$")
	public void prompt_user_to_write_input_correctly() throws Throwable {

	}

	@When("^User does not enter mobile number$")
	public void user_does_not_enter_mobile_number() throws Throwable {

	}

	@Then("^prompt user to enter mobile number$")
	public void prompt_user_to_enter_mobile_number() throws Throwable {

	}

	@When("^User enters invalid mobile no\\.$")
	public void user_enters_invalid_mobile_no(DataTable arg1) throws Throwable {
	   
	   
	}

	@Then("^prompt user to enter valid contact details$")
	public void prompt_user_to_enter_valid_contact_details() throws Throwable {

	}

	@When("^User does not select number of people$")
	public void user_does_not_select_number_of_people() throws Throwable {

	}

	@Then("^prompt user to select the number of people$")
	public void prompt_user_to_select_the_number_of_people() throws Throwable {

	}

	@When("^User does not address$")
	public void user_does_not_address() throws Throwable {

	}

	@Then("^prompt user to fill in the address$")
	public void prompt_user_to_fill_in_the_address() throws Throwable {

	}

	@When("^User does not select city$")
	public void user_does_not_select_city() throws Throwable {

	}

	@Then("^prompt user to select city$")
	public void prompt_user_to_select_city() throws Throwable {

	}

	@When("^User does not select state$")
	public void user_does_not_select_state() throws Throwable {

	}

	@Then("^prompt user to select state$")
	public void prompt_user_to_select_state() throws Throwable {

	}

	@When("^User does not enter card holder name$")
	public void user_does_not_enter_card_holder_name() throws Throwable {

	}

	@Then("^prompt user to fill in card holder name$")
	public void prompt_user_to_fill_in_card_holder_name() throws Throwable {

	}

	@When("^User does not enter debit card number$")
	public void user_does_not_enter_debit_card_number() throws Throwable {

	}

	@Then("^prompt user to enter debit card number$")
	public void prompt_user_to_enter_debit_card_number() throws Throwable {

	}

	@When("^User does not enter card expiration month$")
	public void user_does_not_enter_card_expiration_month() throws Throwable {

	}

	@Then("^prompt user to enter card expiration month$")
	public void prompt_user_to_enter_card_expiration_month() throws Throwable {

	}

	@When("^User does not enter card expiration year$")
	public void user_does_not_enter_card_expiration_year() throws Throwable {

	}

	@Then("^prompt user to enter card expiration year$")
	public void prompt_user_to_enter_card_expiration_year() throws Throwable {

	}

	@When("^User clicks on confirm booking button$")
	public void user_clicks_on_confirm_booking_button() throws Throwable {

	}

	@Then("^navigate to booking successful$")
	public void navigate_to_booking_successful() throws Throwable {

	}

}
