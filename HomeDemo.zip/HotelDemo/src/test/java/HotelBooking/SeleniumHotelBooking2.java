package HotelBooking;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumHotelBooking2 {

	public static void main(String[] args) {
		// TODO Auto-generated constructor stub
		
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Module%203/hotelBooking/hotelbooking.html");
		String title = driver.getTitle();
		
		if(title.contentEquals("Hotel Booking")) {
			
			System.out.println("====VALID TITLE====");
		}
		
		else{
			
		System.out.println("====INVALID TITLE====");
	}
		//For blank first name
		
		driver.findElement(By.id("txtFirstName")).sendKeys("");
		

		driver.findElement(By.id("btnPayment")).click();
		
		driver.switchTo().alert();
		
		
		
	}

}
