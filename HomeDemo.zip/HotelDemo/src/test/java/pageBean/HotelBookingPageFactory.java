package pageBean;

public class HotelBookingPageFactory {

	public HotelBookingPageFactory() {
		// TODO Auto-generated constructor stub
	}

}
