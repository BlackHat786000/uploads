package HotelLogin;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class SeleniumHotelLogin {

	
		public static void main(String[] args) throws Exception {
			
			WebDriver driver = new FirefoxDriver();
			
			driver.navigate().to("file:///D:/Module%203/hotelBooking/login.html/");
		//	driver.get("file:///D:/Module%203/hotelBooking/login.html/");
			String strheading = driver.findElement(By.xpath(".//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
			
			
			if(strheading.contentEquals("Hotel Booking Application"))
			{
				System.out.println("Heading Matched");
			}
			else {
				System.out.println("Heading not found");
			}
			
			
			System.out.println(driver.getCurrentUrl());
			
			Thread.sleep(3000);
			driver.findElement(By.name("userName")).sendKeys("capgemini");
			Thread.sleep(3000);
			driver.findElement(By.name("userPwd")).sendKeys("capg1234");
		//	driver.findElement(By.name("userPwd")).sendKeys("capg12345");
			Thread.sleep(3000);
			driver.findElement(By.className("btn")).click();
			String alertMessage = driver.switchTo().alert().getText();
			System.out.println(alertMessage);
			Thread.sleep(3000);
			driver.switchTo().alert().accept();
			driver.navigate().to("file:///D:/Module%203/hotelBooking/hotelbooking.html/");
		//	driver.get("file:///D:/Module%203/hotelBooking/hotelbooking.html/");
			System.out.println(driver.getCurrentUrl());
		    
			
			
			
			//driver.close();
			//driver.quit();
		
		
		
		
	}

}
