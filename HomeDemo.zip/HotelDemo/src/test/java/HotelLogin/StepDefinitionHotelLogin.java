package HotelLogin;

import static org.testng.Assert.assertEquals;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.HotelLoginPageFactory;

public class StepDefinitionHotelLogin {
	
	private WebDriver driver;
	private HotelLoginPageFactory obj;

	@Given("^user is on login page$")
	public void user_is_on_login_page() throws Throwable {
		
		driver = new FirefoxDriver();
		Thread.sleep(1000);
		obj = new HotelLoginPageFactory(driver);
		
		driver.get("file:///D:/Module%203/hotelBooking/login.html/");
	}

	@Then("^check the heading of page$")
	public void check_the_heading_of_page() throws Throwable {
		
		String strheading = driver.findElement(By.xpath(".//*[@id='mainCnt']/div[1]/div[1]/h1")).getText();
		if(strheading.contentEquals("Hotel Booking Application")) {
			System.out.println("Heading Matched");
		}
		else {
			System.out.println("Heading Not Matched");
		}

	}

	@When("^user enters valid username and password$")
	public void user_enters_valid_username_and_password() throws Throwable {
		
		obj.setPfuname("capgemini");
		obj.setPfpwd("capg1234");
		obj.setPflogin();
		driver.close();

	}

	@Then("^navigate to hotelbooking$")
	public void navigate_to_hotelbooking() throws Throwable {
		
		driver.navigate().to("file:///D:/Module%203/hotelBooking/hotelbooking.html");
		driver.close();

	}

	@When("^user name doesnot enter either username or password$")
	public void user_name_doesnot_enter_either_username_or_password() throws Throwable {
		obj.setPfuname("");
		obj.setPfpwd("capg1234");

	}

	@When("^clicks the login button$")
	public void clicks_the_login_button() throws Throwable {
		obj.setPflogin();
		
	}

	@Then("^display appropiate error message$")
	public void display_appropiate_error_message() throws Throwable {
		String errormsg = driver.findElement(By.xpath("//*[@id='userErrMsg']")).getText();
		assertEquals(errormsg, "* Please enter userName.");
	}

	@When("^user enters incorrect username or password$")
	public void user_enters_incorrect_username_or_password() throws Throwable {
		obj.setPfuname("cg");
		obj.setPfpwd("capg1234");
		Thread.sleep(6000);
		obj.setPflogin();
	}

	@Then("^display login failed message$")
	public void display_login_failed_message() throws Throwable {
		String loginerr = driver.switchTo().alert().getText();
		System.out.println(loginerr);
		driver.switchTo().alert().accept();

	}
}
